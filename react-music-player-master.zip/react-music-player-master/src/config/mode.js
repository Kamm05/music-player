export const MODE = {
  FULL: 'full',
  MINI: 'mini',
}
