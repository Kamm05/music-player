export default {
  selector: 'audio-lists-panel-content-wrap',
  swapClass: 'audio-lists-panel-sortable-highlight-bg',
  swap: true,
  animation: 100,
  easing: 'cubic-bezier(0.43, -0.1, 0.16, 1.1)',
}
