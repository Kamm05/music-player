export default {
  order: 'order',
  orderLoop: 'orderLoop',
  singleLoop: 'singleLoop',
  shufflePlay: 'shufflePlay',
}
