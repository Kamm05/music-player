export const AUDIO_LIST_REMOVE_ANIMATE_TIME = 350 // 列表删除动画时间(ms)
